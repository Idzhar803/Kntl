// BOT TELE
module.exports = {
  BOT_TOKEN: "7728674402:AAGQu_Grt6Tl8mfix8cNu2Vt_3bTMWg-KcQ", // Token bot Telegram
  OWNER_ID: "7296758116", // ID pemilik bot
  allowedGroupIds: [-1002401306074, -1002361556670, -1002386380830, -1002415460020, -4514397992], // ID grup yang diizinkan
};